module.exports = [
    {
        id : 1,
        username : 'testuser1',
        email : 'testuser1@gmail.com',
        password : '1111'
    },
    {
        id : 2,
        username : 'testuser2',
        email : 'testuser2@gmail.com',
        password : '2222'
    },
    {
        id : 3,
        username : 'testuser3',
        email : 'testuser3@gmail.com',
        password : '3333'
    },
    {
        id : 4,
        username : 'testuser4',
        email : 'testuser4@gmail.com',
        password : '4444'
    },
]